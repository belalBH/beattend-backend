import { useState, useEffect } from "react";
import { Profile, Engagement, CheckInLog, HRRequest } from "./types";
import {
  INITIAL_PROFILE,
  INITIAL_ENGAGEMENTS,
  INITIAL_CHECKINS,
  INITIAL_REQUESTS,
} from "./data";
import Header from "./components/Header";
import BottomNav from "./components/BottomNav";
import CheckInCard from "./components/CheckInCard";
import StatsCard from "./components/StatsCard";
import EngagementsCard from "./components/EngagementsCard";
import TeamSentimentCard from "./components/TeamSentimentCard";
import ProfileView from "./components/ProfileView";
import RequestsView from "./components/RequestsView";
import ReportsView from "./components/ReportsView";
import AttendanceCalendarView from "./components/AttendanceCalendarView";

export default function App() {
  const [activeTab, setActiveTab] = useState<"dashboard" | "requests" | "attendance" | "reports" | "profile">("dashboard");

  // Load state from localStorage or initial data
  const [profile, setProfile] = useState<Profile>(() => {
    const saved = localStorage.getItem("crystal_profile");
    return saved ? JSON.parse(saved) : INITIAL_PROFILE;
  });

  const [requests, setRequests] = useState<HRRequest[]>(() => {
    const saved = localStorage.getItem("crystal_requests");
    return saved ? JSON.parse(saved) : INITIAL_REQUESTS;
  });


  const [engagements, setEngagements] = useState<Engagement[]>(() => {
    const saved = localStorage.getItem("crystal_engagements");
    return saved ? JSON.parse(saved) : INITIAL_ENGAGEMENTS;
  });

  const [logs, setLogs] = useState<CheckInLog[]>(() => {
    const saved = localStorage.getItem("crystal_logs");
    return saved ? JSON.parse(saved) : INITIAL_CHECKINS;
  });

  const [checkedIn, setCheckedIn] = useState<boolean>(() => {
    const saved = localStorage.getItem("crystal_checked_in");
    return saved ? JSON.parse(saved) === "true" : true; // Default checked-in matching the mockup
  });

  const [checkInTime, setCheckInTime] = useState<string | null>(() => {
    return localStorage.getItem("crystal_check_in_time") || "08:45 AM";
  });

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem("crystal_profile", JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem("crystal_requests", JSON.stringify(requests));
  }, [requests]);

  useEffect(() => {
    localStorage.setItem("crystal_engagements", JSON.stringify(engagements));
  }, [engagements]);

  useEffect(() => {
    localStorage.setItem("crystal_logs", JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem("crystal_checked_in", checkedIn ? "true" : "false");
  }, [checkedIn]);

  useEffect(() => {
    if (checkInTime) {
      localStorage.setItem("crystal_check_in_time", checkInTime);
    } else {
      localStorage.removeItem("crystal_check_in_time");
    }
  }, [checkInTime]);

  const handleToggleCheckIn = (method: "Fingerprint" | "NFC" | "Manual Override") => {
    const now = new Date();
    const timeString = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const dateString = now.toISOString().split("T")[0];

    if (checkedIn) {
      // Clock out
      const newLog: CheckInLog = {
        id: "log-" + Math.random().toString(36).substr(2, 9),
        timestamp: timeString,
        date: dateString,
        type: "check-out",
        method,
      };
      setLogs([newLog, ...logs]);
      setCheckedIn(false);
      setCheckInTime(null);
      // Update profile status
      setProfile((prev) => ({ ...prev, officeStatus: "OUT_OF_OFFICE" }));
    } else {
      // Clock in
      const newLog: CheckInLog = {
        id: "log-" + Math.random().toString(36).substr(2, 9),
        timestamp: timeString,
        date: dateString,
        type: "check-in",
        method,
      };
      setLogs([newLog, ...logs]);
      setCheckedIn(true);
      setCheckInTime(timeString);
      setProfile((prev) => ({ ...prev, officeStatus: "ACTIVE" }));
    }
  };

  const handleAddEngagement = (newEng: Omit<Engagement, "id">) => {
    const created: Engagement = {
      ...newEng,
      id: "eng-" + Math.random().toString(36).substr(2, 9),
    };
    setEngagements([created, ...engagements]);
  };

  const handleDeleteEngagement = (id: string) => {
    setEngagements(engagements.filter((e) => e.id !== id));
  };

  const handleUpdateCompletedHours = (hours: number) => {
    setProfile((prev) => ({ ...prev, completedHours: Math.max(0, hours) }));
  };

  const handleUpdateTargetHours = (hours: number) => {
    setProfile((prev) => ({ ...prev, weeklyTargetHours: Math.max(1, hours) }));
  };

  const handleUpdateProfile = (updated: Profile) => {
    setProfile(updated);
  };

  const handleAddRequest = (newReq: Omit<HRRequest, "id" | "dateSubmitted" | "status">) => {
    const created: HRRequest = {
      ...newReq,
      id: "req-" + Math.random().toString(36).substr(2, 9),
      dateSubmitted: new Date().toISOString().split("T")[0],
      status: "pending",
    };
    setRequests([created, ...requests]);
  };

  const handleUpdateRequestStatus = (id: string, status: HRRequest["status"]) => {
    setRequests(requests.map((r) => r.id === id ? { ...r, status } : r));
  };

  const handleDeleteRequest = (id: string) => {
    setRequests(requests.filter((r) => r.id !== id));
  };

  const handleClearLogs = () => {
    setLogs([]);
  };

  const handleAddCustomLog = (date: string, time: string, type: "check-in" | "check-out", method: CheckInLog["method"]) => {
    const newLog: CheckInLog = {
      id: "log-" + Math.random().toString(36).substr(2, 9),
      timestamp: time,
      date,
      type,
      method,
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  const handleDeleteLog = (id: string) => {
    setLogs((prev) => prev.filter((l) => l.id !== id));
  };

  return (

    <div className="min-h-screen text-white flex flex-col font-sans select-none relative">
      {/* Ambient background blur */}
      <div className="fixed inset-0 mesh-bg -z-10" />

      {/* Global Navbar Header */}
      <Header
        profile={profile}
        onOpenProfile={() => setActiveTab("profile")}
        logsCount={logs.length}
      />

      {/* Primary Container Viewport */}
      <main className="flex-1 relative pt-24 pb-32 px-6 md:px-12 max-w-7xl mx-auto w-full space-y-6">
        
        {/* Active viewport routing conditional checks */}
        {activeTab === "dashboard" && (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* Welcome banner segment */}
            <section className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
              <div>
                <p className="font-mono text-xs text-brand-secondary font-bold uppercase tracking-widest mb-1 animate-pulse">
                  Welcome back,
                </p>
                <h2 className="text-3xl font-black text-white leading-tight">
                  {profile.name}
                </h2>
              </div>
              
              <div className="flex items-center gap-2.5 px-4 py-2.5 glass-card rounded-full border border-white/10 shadow-lg">
                <span className={`w-2.5 h-2.5 rounded-full shadow-lg ${
                  profile.officeStatus === "ACTIVE" 
                    ? "bg-brand-secondary shadow-brand-secondary/60 animate-pulse" 
                    : profile.officeStatus === "REMOTE" 
                    ? "bg-emerald-400 shadow-emerald-400/60" 
                    : "bg-rose-400 shadow-rose-400/60"
                }`} />
                <span className="font-mono text-[10px] font-bold text-neutral-300 tracking-widest uppercase">
                  OFFICE STATUS: {profile.officeStatus === "ACTIVE" ? "ACTIVE" : profile.officeStatus === "REMOTE" ? "REMOTE" : "OUT OF OFFICE"}
                </span>
              </div>
            </section>

            {/* Main grid structure */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Check-in Orb */}
              <div className="lg:col-span-7">
                <CheckInCard
                  checkedIn={checkedIn}
                  onToggleCheckIn={handleToggleCheckIn}
                  checkInTime={checkInTime}
                  logs={logs}
                  profile={profile}
                />
              </div>

              {/* Stats column bento cards */}
              <div className="lg:col-span-5">
                <StatsCard
                  profile={profile}
                  onUpdateCompletedHours={handleUpdateCompletedHours}
                  onUpdateTargetHours={handleUpdateTargetHours}
                />
              </div>

            </div>

            {/* Lower row items */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Next Engagements Agenda layout */}
              <div className="lg:col-span-8">
                <EngagementsCard
                  engagements={engagements}
                  onAddEngagement={handleAddEngagement}
                  onDeleteEngagement={handleDeleteEngagement}
                />
              </div>

              {/* Cognitive Sentiment analysis segments */}
              <div className="lg:col-span-4">
                <TeamSentimentCard
                  profile={profile}
                  engagements={engagements}
                  checkedIn={checkedIn}
                />
              </div>

            </div>
          </div>
        )}

        {activeTab === "requests" && (
          <RequestsView
            requests={requests}
            onAddRequest={handleAddRequest}
            onUpdateRequestStatus={handleUpdateRequestStatus}
            onDeleteRequest={handleDeleteRequest}
          />
        )}

        {activeTab === "attendance" && (
          <AttendanceCalendarView
            logs={logs}
            onAddCustomLog={handleAddCustomLog}
            onDeleteLog={handleDeleteLog}
            profile={profile}
          />
        )}

        {activeTab === "reports" && (
          <ReportsView
            profile={profile}
            logs={logs}
            onClearLogs={handleClearLogs}
          />
        )}

        {activeTab === "profile" && (
          <ProfileView
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
          />
        )}
      </main>

      {/* Floating Bottom Navigation Bar */}
      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
}
